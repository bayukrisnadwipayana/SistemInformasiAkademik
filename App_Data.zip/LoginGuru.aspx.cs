﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Latihan;
using System.Security.Cryptography;

namespace SistemAkademik
{
    public partial class LoginGuru : System.Web.UI.Page
    {
        guru guru = new guru();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void EventLoginGuru(object sender, EventArgs e)
        {
            /*if (guru.GetUserAndPassword(usernameguru.Value, passwordguru.Value))
            {
                Response.Redirect("AkunGuru.aspx");
            }
            else
            {
                Response.Redirect("LoginGuru.aspx");
            }
             */
            Response.Write(guru.ConvertMD5PasswordGuru(passwordguru.Value).ToString());
        }
    }
}